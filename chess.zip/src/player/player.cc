#include "player.h"

Player::~Player() {};
bool Player::isHumanPlayer() const {
  return isHuman;
}